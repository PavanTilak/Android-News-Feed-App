package com.ust.feedsapp;

import android.content.Intent;
import androidx.test.filters.MediumTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

@MediumTest
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule  = new  ActivityTestRule<>(MainActivity.class);

    @Test
    public void launchActivity() {
        Intent intent = new Intent();
        mActivityTestRule.launchActivity(intent);
    }

    @Test
    public void isViewVisible() {
        onView(withId(R.id.recycler_view)).check(matches(isDisplayed()));
    }

    /*@Test
    public void clickOnItemWithTextEqualTo() {

        // Find the adapter position to click based on matching the text "two" to the adapter item's text
        onData(allOf(is(instanceOf(String.class)), is("Value"))) // Use Hamcrest matchers to match item
                .inAdapterView(withId(R.id.recycler_view)) // Specify the explicit id of the ListView
                .perform(click()); // Standard ViewAction
    }
    @Test
    public void clickOnItematPosition() {
        onData(anything()) // We are using the position so don't need to specify a data matcher
                .inAdapterView(withId(R.id.recycler_view)) // Specify the explicit id of the ListView
                .atPosition(1) // Explicitly specify the adapter item to use
                .perform(click()); // Standard ViewAction
    }*/

}