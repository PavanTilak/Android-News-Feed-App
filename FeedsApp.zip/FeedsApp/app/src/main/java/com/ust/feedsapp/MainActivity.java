package com.ust.feedsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.ust.feedsapp.adapter.FeedsAdapter;
import com.ust.feedsapp.backend.ApiCall;
import com.ust.feedsapp.interfaces.IApiResponseCallback;
import com.ust.feedsapp.model.Cards;
import com.ust.feedsapp.utilities.Utils;

import java.util.List;

public class MainActivity extends AppCompatActivity implements IApiResponseCallback {

    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mRecyclerAdapter;
    private RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViewIds();

        //code to check for internet connection
        if(Utils.haveNetworkConnection(this)) {
            new ApiCall(this);
        } else {
            Toast.makeText(MainActivity.this, getResources().getText(R.string.network_failure), Toast.LENGTH_LONG).show();
        }
    }

    private void initViewIds() {
        mRecyclerView = findViewById(R.id.recycler_view);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
    }

    /**
     * This Interface api method , will be called after getting the API response from server
     * This will update the row Adapter with server data
     */
    @Override
    public void onApiResponse(List<Cards> cards) {
        mRecyclerAdapter = new FeedsAdapter(cards);
        mRecyclerView.setAdapter(mRecyclerAdapter);
    }
}
