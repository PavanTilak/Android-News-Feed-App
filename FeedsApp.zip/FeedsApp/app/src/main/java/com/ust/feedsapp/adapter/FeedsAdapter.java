package com.ust.feedsapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;
import com.ust.feedsapp.R;
import com.ust.feedsapp.model.Attributes;
import com.ust.feedsapp.model.Cards;
import com.ust.feedsapp.model.Description;
import com.ust.feedsapp.model.Image;
import com.ust.feedsapp.model.Title;

import java.util.List;

public class FeedsAdapter extends RecyclerView.Adapter<FeedsAdapter.ViewHolder> {

    private List<Cards> mCardsList;

    public FeedsAdapter(List<Cards> mCardsList) {
        this.mCardsList = mCardsList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.feed_row, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.definition.setText("CardType : "+mCardsList.get(position).getCard_type()+"\n"+
        "Value : "+ mCardsList.get(position).getCard().getValue()
        );

        Attributes attributes = mCardsList.get(position).getCard().getAttributes();
        if(attributes != null) {
            holder.attributes.setText("TextColor : "+ attributes.getText_color()+"\n"+
                    "FontSize : "+ attributes.getFont().getSize());
        }

        Title title = mCardsList.get(position).getCard().getTitle();
        if(title != null) {
            holder.title.setText("Title Value : "+title.getValue());
        }

        Description description = mCardsList.get(position).getCard().getDescription();
        if(description != null) {
            holder.description.setText("Description Value : "+description.getValue());
        }

        Image image = mCardsList.get(position).getCard().getImage();
        if(image != null) {
            holder.imageSize.setText(" Image Width : "+image.getSize().getWidth()+"\n"+
                    " Image Height : "+image.getSize().getHeight());

            holder.imageView.setVisibility(View.VISIBLE);
            Picasso.get().load(image.getUrl()).into(holder.imageView);
        } else {
            holder.imageView.setVisibility(View.GONE);
        }
    }


    @Override
    public int getItemCount() {
        if (mCardsList != null) {
            return mCardsList.size();
        } else {
            return 0;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public final View view;
        public final ImageView imageView;
        public final TextView definition;
        public final TextView attributes;
        public final TextView title;
        public final TextView description;
        public final TextView imageSize;

        public ViewHolder(View view) {
            super(view);
            this.view = view;
            imageView = view.findViewById(R.id.imageView);
            definition = view.findViewById(R.id.definition);
            attributes = view.findViewById(R.id.attributes);
            title = view.findViewById(R.id.title);
            description = view.findViewById(R.id.description);
            imageSize = view.findViewById(R.id.imageSize);
        }
    }

}
