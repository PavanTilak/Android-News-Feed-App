package com.ust.feedsapp.backend;

import android.app.Activity;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ust.feedsapp.interfaces.FeedData;
import com.ust.feedsapp.interfaces.IApiResponseCallback;
import com.ust.feedsapp.model.Root;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import static com.ust.feedsapp.utilities.Utils.BASE_URL;

/**
 * This class used to perform the backend api call
 */
public class ApiCall implements Callback<Root> {

    private IApiResponseCallback iApiResponseCallback = null;

    public ApiCall(Activity activity) {
        iApiResponseCallback = (IApiResponseCallback)activity;
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        FeedData gerritAPI = retrofit.create(FeedData.class);

        Call<Root> call = gerritAPI.getFeedData();
        call.enqueue(this);
    }

    @Override
    public void onResponse(Call<Root> call, Response<Root> response) {
        Log.d("ApiCall","Success response "+response.body() );
        Root root = response.body();
        if(root != null && root.getPage() != null) {
            //Send response to MainActivity to update the adapter rows
            iApiResponseCallback.onApiResponse(root.getPage().getCards());
        }
    }

    @Override
    public void onFailure(Call<Root> call, Throwable t) {
        Log.e("ApiCall","Failure response for Api call");
    }

}
