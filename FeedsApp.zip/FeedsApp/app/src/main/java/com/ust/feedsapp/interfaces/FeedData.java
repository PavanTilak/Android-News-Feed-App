package com.ust.feedsapp.interfaces;

import com.ust.feedsapp.model.Root;
import retrofit2.Call;
import retrofit2.http.GET;

public interface FeedData {

    @GET("test/home")
    Call<Root> getFeedData();
}
