package com.ust.feedsapp.interfaces;

import com.ust.feedsapp.model.Cards;
import java.util.List;

public interface IApiResponseCallback {
    void onApiResponse(List<Cards> cards);
}
