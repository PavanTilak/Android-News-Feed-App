package com.ust.feedsapp.model;

public class Attributes {
    private String text_color;

    private Font font;

    public void setText_color(String text_color){
        this.text_color = text_color;
    }
    public String getText_color(){
        return this.text_color;
    }
    public void setFont(Font font){
        this.font = font;
    }
    public Font getFont(){
        return this.font;
    }
}
