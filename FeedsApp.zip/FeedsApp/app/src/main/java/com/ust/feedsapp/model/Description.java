package com.ust.feedsapp.model;

public class Description {
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    public Description(String value, Attributes attributes) {
        this.value = value;
        this.attributes = attributes;
    }

    private String value;
    private Attributes attributes;
}
