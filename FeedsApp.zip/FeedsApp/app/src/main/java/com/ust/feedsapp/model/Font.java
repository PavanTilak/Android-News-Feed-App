package com.ust.feedsapp.model;

public class Font {
    private int size;

    public void setSize(int size){
        this.size = size;
    }
    public int getSize(){
        return this.size;
    }
}
