package com.ust.feedsapp.model;

public class Image {
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public Image(String url, Size size) {
        this.url = url;
        this.size = size;
    }

    private String url;
    private Size size;
}
