package com.ust.feedsapp.model;

import java.util.List;

public class Page {

    private List<Cards> cards;

    public void setCards(List<Cards> cards){
        this.cards = cards;
    }
    public List<Cards> getCards(){
        return this.cards;
    }

}
