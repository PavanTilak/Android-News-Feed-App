package com.ust.feedsapp.model;

public class Root {
    private Page page;

    public void setPage(Page page){
        this.page = page;
    }
    public Page getPage(){
        return this.page;
    }
}
